:::::::::: World Times Theme ::::::::::

Theme Name: World Times
Theme URI: http://gbjsolution.com/
Author: GBJ solution
Author URI: http://themeforest.net/user/GBJsolution
Description: Minimal blog and magazine WordPress theme
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: featured-images, theme-options, translation-ready
Text Domain: world-times

:::::::::: Licenses ::::::::::

World Times theme uses the following third party resources.

1. Bootstrap v4.1.3 [ http://getbootstrap.com/ ]
Licence:- Licensed under MIT - https://github.com/twbs/bootstrap/blob/master/LICENSE

2. Fitvids.js [ http://fitvidsjs.com/ ]
Licence:- Released under the WTFPL license - http://sam.zoy.org/wtfpl/

3. highlight.js [ https://highlightjs.org/ ]
Licence:- Highlight.js is released under the BSD License - https://github.com/isagalaev/highlight.js/blob/master/LICENSE

4. Magnific Popup [ https://github.com/dimsemenov/Magnific-Popup ]
Licence:- Licensed under MIT - https://github.com/dimsemenov/Magnific-Popup/blob/master/LICENSE

:::::::::: Google Fonts ::::::::::

1. Lato [ https://fonts.google.com/specimen/Lato ]
Licence:- Open Font Licence - http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web

1. PT Serif [ https://fonts.google.com/specimen/PT+Serif ]
Licence:- Open Font Licence - http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web