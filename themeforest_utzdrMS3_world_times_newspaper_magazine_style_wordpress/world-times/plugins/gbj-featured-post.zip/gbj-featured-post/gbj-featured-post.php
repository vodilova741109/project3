<?php
/*
Plugin Name: GBJ Featured Post
Plugin URI:  http://gbjsolution.com/
Description: It's a custom plugin for GBJ solution's themes. It adds a featured meta box in posts
Version:     1.0
Author:      GBJ solution
Author URI:  http://gbjsolution.com/
Domain Path: /languages
Text Domain: gbj-featured-post
*/

// prevent direct access
defined( 'ABSPATH' ) or die( 'No Direct Access' );

function gbj_featured_post_add_featured_meta_box()
{
    add_meta_box(
        'gbj_featured_post_box_id',
        'featured Post',
        'gbj_featured_post_featured_meta_box_html',
        'post',
        'side'
    );
}
add_action('add_meta_boxes', 'gbj_featured_post_add_featured_meta_box');

function gbj_featured_post_featured_meta_box_html($post)
{
    $gbj_featured_post_featured = get_post_meta($post->ID, '_gbj_featured_post', true);
    ?>
    <div>
        <label for="featured_post">Feature this post?</label>
        <select name="featured_post" id="featured_post">
            <option value="no" <?php selected($gbj_featured_post_featured, 'no'); ?>>No</option>
            <option value="yes" <?php selected($gbj_featured_post_featured, 'yes'); ?>>Yes</option>
        </select>
    </div>
    <?php
}
function gbj_featured_post_save_postdata($post_id)
{
    if (array_key_exists('featured_post', $_POST)) {
        update_post_meta(
            $post_id,
            '_gbj_featured_post',
            $_POST['featured_post']
        );
    }
    
}
add_action('save_post', 'gbj_featured_post_save_postdata');

add_action( 'plugins_loaded', 'gbj_featured_post_load_textdomain' );
function gbj_featured_post_load_textdomain() {
	load_plugin_textdomain('gbj-featured-post', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
}