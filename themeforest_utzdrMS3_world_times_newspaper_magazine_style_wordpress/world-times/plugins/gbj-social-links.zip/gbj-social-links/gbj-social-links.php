<?php
/*
Plugin Name: GBJ Social Links
Plugin URI:  http://gbjsolution.com/
Description: It's a custom plugin for GBJ solution's themes. It adds a Social Links Widget
Version:     1.0
Author:      GBJ solution
Author URI:  http://gbjsolution.com/
Domain Path: /languages
Text Domain: gbj-social-links
*/

// prevent direct access
defined( 'ABSPATH' ) or die( 'No Direct Access' );

/*====================================================
	social links widget
====================================================*/
class gbj_social_links_widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		parent::__construct(
			'gbj_social_links_widget', // base ID
			esc_html__( 'GBJ - Social Link Widget', 'gbj-social-links' ), // Name
			array( 'description' => esc_html__( 'This widget shows the social icons', 'gbj-social-links' ), ) // Args
		);
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
        $allowed_html = array(
			'div' => array(
				'id' => array(),
				'class' => array()
			),
			'h4' => array(
				'id' => array(),
				'class' => array()
			)
		);
		// outputs the content of the widget
		echo wp_kses($args['before_widget'], $allowed_html);
		if ( ! empty($instance['title']) ) {
			echo wp_kses($args['before_title'], $allowed_html) . apply_filters( 'widget_title', $instance['title'] ) . wp_kses($args['after_title'], $allowed_html);
		}
		?>
		<div class="content">
			<ul class="social-links">
			<?php
			if (!empty($instance['twitter_url'])) {
				echo '<li><a href="' . esc_url($instance['twitter_url']) . '">';
                get_template_part('partials/icons/twitter');
                echo '</a></li>';
            }
            if (!empty($instance['facebook_url'])) {
                echo '<li><a href="' . esc_url($instance['facebook_url']) . '">';
                get_template_part('partials/icons/facebook');
                echo '</a></li>';
			}
            if (!empty($instance['instagram_url'])) {
				echo '<li><a href="' . esc_url($instance['instagram_url']) . '">';
                get_template_part('partials/icons/instagram');
                echo '</a></li>';
			}
			if (!empty($instance['dribbble_url'])) {
				echo '<li><a href="' . esc_url($instance['dribbble_url']) . '">';
                get_template_part('partials/icons/dribbble');
                echo '</a></li>';
            }
            if (!empty($instance['behance_url'])) {
				echo '<li><a href="' . esc_url($instance['behance_url']) . '">';
                get_template_part('partials/icons/behance');
                echo '</a></li>';
			}
			if (!empty($instance['medium_url'])) {
				echo '<li><a href="' . esc_url($instance['medium_url']) . '">';
                get_template_part('partials/icons/medium');
                echo '</a></li>';
            }
            if (!empty($instance['pinterest_url'])) {
				echo '<li><a href="' . esc_url($instance['pinterest_url']) . '">';
                get_template_part('partials/icons/pinterest');
                echo '</a></li>';
			}
			if (!empty($instance['youtube_url'])) {
				echo '<li><a href="' . esc_url($instance['youtube_url']) . '">';
                get_template_part('partials/icons/youtube');
                echo '</a></li>';
			}
			if (!empty($instance['google_plus_url'])) {
				echo '<li><a href="' . esc_url($instance['google_plus_url']) . '">';
                get_template_part('partials/icons/google-plus');
                echo '</a></li>';
			}
			if (!empty($instance['linkedin_url'])) {
				echo '<li><a href="' . esc_url($instance['linkedin_url']) . '">';
                get_template_part('partials/icons/linkedin');
                echo '</a></li>';
			}
			?>
			</ul>
		</div>
		<?php
		echo wp_kses($args['after_widget'], $allowed_html);
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		// outputs the options form on admin
		$title = ! empty($instance['title']) ? $instance['title'] : esc_html__( 'Social', 'gbj-social-links' );
        $twitter_url = !empty($instance['twitter_url']) ? $instance['twitter_url'] : '';
		$facebook_url = !empty($instance['facebook_url']) ? $instance['facebook_url'] : '';
		$instagram_url = !empty($instance['instagram_url']) ? $instance['instagram_url'] : '';
        $dribbble_url = !empty($instance['dribbble_url']) ? $instance['dribbble_url'] : '';
        $behance_url = !empty($instance['behance_url']) ? $instance['behance_url'] : '';
        $medium_url = !empty($instance['medium_url']) ? $instance['medium_url'] : '';
		$pinterest_url = !empty($instance['pinterest_url']) ? $instance['pinterest_url'] : '';
		$youtube_url = !empty($instance['youtube_url']) ? $instance['youtube_url'] : '';
		$google_plus_url = !empty($instance['google_plus_url']) ? $instance['google_plus_url'] : '';
		$linkedin_url = !empty($instance['linkedin_url']) ? $instance['linkedin_url'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php _e( 'Title:', 'gbj-social-links' ); ?></label> 
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('twitter_url')) ?>"><?php _e( 'Twitter URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('twitter_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'twitter_url' )); ?>" type="text" value="<?php echo esc_attr( $twitter_url ); ?>">
        </p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('facebook_url')) ?>"><?php _e( 'Facebook URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('facebook_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'facebook_url' )); ?>" type="text" value="<?php echo esc_attr( $facebook_url ); ?>">
		</p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('instagram_url')) ?>"><?php _e( 'Instagram URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('instagram_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'instagram_url' )); ?>" type="text" value="<?php echo esc_attr( $instagram_url ); ?>">
		</p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('dribbble_url')) ?>"><?php _e( 'Dribbble URL', 'gbj-social-links' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('dribbble_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'dribbble_url' )); ?>" type="text" value="<?php echo esc_attr( $dribbble_url ); ?>">
        </p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('behance_url')) ?>"><?php _e( 'Behance URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('behance_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'behance_url' )); ?>" type="text" value="<?php echo esc_attr( $behance_url ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('medium_url')) ?>"><?php _e( 'Medium URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('medium_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'medium_url' )); ?>" type="text" value="<?php echo esc_attr( $medium_url ); ?>">
		</p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('pinterest_url')) ?>"><?php _e( 'Pinterest URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('pinterest_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'pinterest_url' )); ?>" type="text" value="<?php echo esc_attr( $pinterest_url ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('youtube_url')) ?>"><?php _e( 'Youtube URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('youtube_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'youtube_url' )); ?>" type="text" value="<?php echo esc_attr( $youtube_url ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('google_plus_url')) ?>"><?php _e( 'Google Plus URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('google_plus_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'google_plus_url' )); ?>" type="text" value="<?php echo esc_attr( $google_plus_url ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('linkedin_url')) ?>"><?php _e( 'Linkedin URL', 'gbj-social-links' ) ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('linkedin_url')) ?>" name="<?php echo esc_attr($this->get_field_name( 'linkedin_url' )); ?>" type="text" value="<?php echo esc_attr( $linkedin_url ); ?>">
		</p>
		
		<?php 
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ! empty($new_instance['title']) ? strip_tags( $new_instance['title'] ) : '';
		$instance['facebook_url'] = !empty($new_instance['facebook_url']) ? strip_tags($new_instance['facebook_url']) : '';
		$instance['twitter_url'] = !empty($new_instance['twitter_url']) ? strip_tags($new_instance['twitter_url']) : '';
		$instance['instagram_url'] = !empty($new_instance['instagram_url']) ? strip_tags($new_instance['instagram_url']) : '';
		$instance['dribbble_url'] = !empty($new_instance['dribbble_url']) ? strip_tags($new_instance['dribbble_url']) : '';
		$instance['behance_url'] = !empty($new_instance['behance_url']) ? strip_tags($new_instance['behance_url']) : '';
		$instance['medium_url'] = !empty($new_instance['medium_url']) ? strip_tags($new_instance['medium_url']) : '';
		$instance['pinterest_url'] = !empty($new_instance['pinterest_url']) ? strip_tags($new_instance['pinterest_url']) : '';
		$instance['youtube_url'] = !empty($new_instance['youtube_url']) ? strip_tags($new_instance['youtube_url']) : '';
		$instance['google_plus_url'] = !empty($new_instance['google_plus_url']) ? strip_tags($new_instance['google_plus_url']) : '';
		$instance['linkedin_url'] = !empty($new_instance['linkedin_url']) ? strip_tags($new_instance['linkedin_url']) : '';
		return $instance;
	}
}
// register custom widgets
function world_times_register_custom_widgets() {
    register_widget( 'gbj_social_links_widget' );
}
add_action( 'widgets_init', 'world_times_register_custom_widgets' );

add_action( 'plugins_loaded', 'gbj_social_links_load_textdomain' );
function gbj_social_links_load_textdomain() {
	load_plugin_textdomain('gbj-social-links', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
}